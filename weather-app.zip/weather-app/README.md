# Projet FullStack Back avec ReactJs/NestJs

Notre application est une suite du projet Front avec ReactJS.
En effet ce projet est une application météologique.

notre application comportera deux zone de texte: 
	-la prémière sera utilisé pour spécifié le nom de ville et 
	-la deuxième utilisé pour spécifié le pays

Ainsi lorsqu'on clique sur "Get Weather", 
nous obtenons les données météologiques actuelles de la ville saisie.
entre autre:
	-le nom de la ville et pays s'affiche 
	-une icone pour représenter la météo,
	-la température en celsius à l'instant t,
	-un intervalle de température minimun et maximum en celsius et
	-la description du l'etat du temps qu'il fait.

## Note: si vous n'avez pas entrer la ville et le pays, un boite de dialogue vous invite à saisir les deux informations demandés afin d'afficher les informations météologiques de la dite zone.

By Lewis TANO - E4 - CCSN

